/* @test /nodynamiccopyright/
 * @compile/fail TestCompile1.java
 */

// no easy way to get at internal compiler options table
// so simply provide an invalid file and use an external
// option to force raw diagnostics
class
