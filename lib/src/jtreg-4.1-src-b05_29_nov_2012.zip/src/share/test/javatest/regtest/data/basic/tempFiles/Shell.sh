#!/bin/sh
# @test
# @summary Passed: Write a temporary file
# @run shell Shell.sh

echo Shell.sh running
echo "file Shell.tmp" > Shell.tmp
