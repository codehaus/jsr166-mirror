package pkg;
import org.testng.annotations.*;

@Test 
public class ATest { 
    public void run() { }
}

